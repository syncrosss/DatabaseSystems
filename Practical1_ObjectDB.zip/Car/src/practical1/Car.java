/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practical1;

import java.io.Serializable;
import javax.persistence.*;
/**
 *
 * @author nicol
 */

// Classe définissant l'objet voiture

@Entity //Cette annotation indique que la classe sera mappée à une table dans une BDD
public class Car implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue
    
    private long id;
    
    private int RegistrationNbr;
    private String Make;
    private String Model;
    private int YearOfManufacture;
    private int TopSpeed;

    // Constructeur par défaut requis par JPA
    public Car() {}
    
    // Constructeur pour initialiser les propriétés de la voiture
    Car(int RegistrationNbr, String Make, String Model, int YearOfManufacture, int TopSpeed) {
        this.RegistrationNbr = RegistrationNbr;
        this.Make = Make;
        this.Model = Model;
        this.YearOfManufacture = YearOfManufacture;
        this.TopSpeed = TopSpeed;
    }
    

    public Long getId() {
        return id;
    }

    public int getRegistrationNbr() {
        return RegistrationNbr;
    }
    public void setRegistrationNbr(int RegistrationNbr){
        this.RegistrationNbr = RegistrationNbr;
    }

    public String getMake() {
        return Make;
    }
    public void setMake(String Make){
        this.Make = Make;
    }

    public String getModel() {
        return Model;
    }
    public void setModel(String Model){
        this.Model = Model;
    }

    public int getYearOfManufacture() {
        return YearOfManufacture;
    }
    public void setYearOfManufacture(int YearOfManufacture){
        this.YearOfManufacture = YearOfManufacture;
    }

    public int getTopSpeed() {
        return TopSpeed;
    }
    public void setTopSpeed(int TopSpeed){
        this.TopSpeed = TopSpeed;
    }

    @Override
    public String toString() {
        return String.format("(%d, %s, %s, %d, %d)", this.RegistrationNbr, this.Make, this.Model, this.YearOfManufacture, this.TopSpeed);
    }
}



