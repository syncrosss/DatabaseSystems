/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practical1;

/**
 *
 * @author nicol
 */

//Cette classe permet de réaliser des operations CRUD sur les voitures de la BDD

import javax.persistence.*;
import java.util.*;

public class CarMain {
    
    // Méthode pour enregistrer une voiture dans la base de données
    public boolean saveCar(Car car) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("$objectdb/db/p1.odb");
        EntityManager em = emf.createEntityManager();

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            em.persist(car);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            e.printStackTrace();
            return false;
        } finally {
            em.close();
            emf.close();
        }
    }

    // Méthode pour obtenir une liste de voitures par numéro d'enregistrement
    public List<Car> getCarsByRegistrationNbr(int registrationNbr) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("$objectdb/db/p1.odb");
        EntityManager em = emf.createEntityManager();

        try {
            TypedQuery<Car> query = em.createQuery("SELECT c FROM Car c WHERE c.RegistrationNbr = :registrationNbr", Car.class);
            query.setParameter("registrationNbr", registrationNbr);

            return query.getResultList();
        } finally {
            em.close();
            emf.close();
        }
    }

    // Méthode pour obtenir toutes les voitures de la base de données
    public List<Car> getAllCars() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("$objectdb/db/p1.odb");
        EntityManager em = emf.createEntityManager();

        try {
            return em.createQuery("SELECT c FROM Car c", Car.class).getResultList();
        } finally {
            em.close();
            emf.close();
        }
    }
    
    // Méthode pour supprimer les doublons de numéros d'enregistrement dans la base de données
    public void removeDuplicateRegistrationNbr() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("$objectdb/db/p1.odb");
        EntityManager em = emf.createEntityManager();

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            List<Car> cars = em.createQuery("SELECT c FROM Car c", Car.class).getResultList();
            Set<Integer> uniqueRegistrationNbrs = new HashSet<>();
            List<Car> carsToRemove = new ArrayList<>();

            for (Car car : cars) {
                int registrationNbr = car.getRegistrationNbr();
                if (uniqueRegistrationNbrs.contains(registrationNbr)) {
                    carsToRemove.add(car);
                } else {
                    uniqueRegistrationNbrs.add(registrationNbr);
                }
            }

            for (Car car : carsToRemove) {
                em.remove(car);
            }

            tx.commit();
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

    // Méthode pour supprimer une voiture par numéro d'enregistrement
    public boolean deleteCarByRegistrationNbr(int registrationNbr) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("$objectdb/db/p1.odb");
        EntityManager em = emf.createEntityManager();

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            TypedQuery<Car> query = em.createQuery("SELECT c FROM Car c WHERE c.RegistrationNbr = :registrationNbr", Car.class);
            query.setParameter("registrationNbr", registrationNbr);
            List<Car> carsToDelete = query.getResultList();

            if (!carsToDelete.isEmpty()) {
                Car carToDelete = carsToDelete.get(0);
                em.remove(carToDelete);
                tx.commit();
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            e.printStackTrace();
            return false;
        } finally {
            em.close();
            emf.close();
        }
    }

    // Méthode pour mettre à jour les informations d'une voiture
    public boolean updateCar(Car updatedCar) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("$objectdb/db/p1.odb");
        EntityManager em = emf.createEntityManager();

        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();

            TypedQuery<Car> query = em.createQuery("SELECT c FROM Car c WHERE c.RegistrationNbr = :registrationNbr", Car.class);
            query.setParameter("registrationNbr", updatedCar.getRegistrationNbr());
            List<Car> carsToUpdate = query.getResultList();

            if (!carsToUpdate.isEmpty()) {
                Car carToUpdate = carsToUpdate.get(0);
                carToUpdate.setMake(updatedCar.getMake());
                carToUpdate.setModel(updatedCar.getModel());
                carToUpdate.setYearOfManufacture(updatedCar.getYearOfManufacture());
                carToUpdate.setTopSpeed(updatedCar.getTopSpeed());

                tx.commit();
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            if (tx.isActive()) {
                tx.rollback();
            }
            e.printStackTrace();
            return false;
        } finally {
            em.close();
            emf.close();
        }
    }

    // Méthode pour réaliser le calcul de la moyenne des vitesses max des voitures de la BDD
    public double calculateAverageTopSpeed() {
        List<Car> cars = getAllCars();

        if (cars.isEmpty()) {
            return 0.0; 
        }

        int totalTopSpeed = 0;
        for (Car car : cars) {
            totalTopSpeed += car.getTopSpeed();
        }

        return (double) totalTopSpeed / cars.size(); 
    } 
}