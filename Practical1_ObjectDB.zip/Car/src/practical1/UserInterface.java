/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practical1;
import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;
import java.util.List;

/**
 *
 * @author nicol
 */

// Cette classe permet de créer l'interface utilisateur pour intéragir avec la BDD et afficher une GUI
// Elle est liée à la classe CarMain pour faire des opérations CRUD sur la BDD

public class UserInterface {
    private CarMain carMain;
    JFrame f = new JFrame("Car informations");

    
    // Déclarations des composants GUI
    JLabel Lbl_RegistrationNbr, Lbl_Make, Lbl_Model, Lbl_YearOfManufacture, Lbl_TopSpeed;
    JTextField TF_RegistrationNbr, TF_Make, TF_Model, TF_YearOfManufacture, TF_TopSpeed;
    
    JTable carTable;
    DefaultTableModel tableModel;
    
    public UserInterface(CarMain carMain) {
        this.carMain = carMain;
        
        Lbl_RegistrationNbr = new JLabel("Registration Number");
        Lbl_RegistrationNbr.setBounds(20, 20, 150, 20);
        TF_RegistrationNbr = new JTextField();
        TF_RegistrationNbr.setBounds(180, 20, 150, 20);

        Lbl_Make = new JLabel("Make");
        Lbl_Make.setBounds(20, 60, 150, 20);
        TF_Make = new JTextField();
        TF_Make.setBounds(180, 60, 150, 20);

        Lbl_Model = new JLabel("Model");
        Lbl_Model.setBounds(20, 100, 150, 20);
        TF_Model = new JTextField();
        TF_Model.setBounds(180, 100, 150, 20);

        Lbl_YearOfManufacture = new JLabel("Year of Manufacture");
        Lbl_YearOfManufacture.setBounds(20, 140, 150, 20);
        TF_YearOfManufacture = new JTextField();
        TF_YearOfManufacture.setBounds(180, 140, 150, 20);

        Lbl_TopSpeed = new JLabel("Top Speed");
        Lbl_TopSpeed.setBounds(20, 180, 150, 20);
        TF_TopSpeed = new JTextField();
        TF_TopSpeed.setBounds(180, 180, 150, 20);
        
        // Bouton "Save" pour enregistrer une nouvelle voiture
        JButton b1 = new JButton("Save");
        b1.setBounds(60, 220, 100, 40);
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveCarDetails();
            }
        });
        
        // Bouton "Search" pour faire une recherche filtrée dans l'affichage en tableau
        JButton b2 = new JButton("Search");
        b2.setBounds(200, 220, 100, 40);
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchCarDetails();
            }
        });
        
        // Bouton "Refresh" pour rafraichir l'affichage en tableau
        JButton b3 = new JButton("Refresh");
        b3.setBounds(340, 220, 100, 40);
        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshCarTable();
            }
        });
        
        // Bouton "Delete" pour supprimer une voiture à partir de son RegistrationID
        JButton b4 = new JButton("Delete");
        b4.setBounds(60, 480, 100, 40);
        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteCar();
            }
        });

        // Bouton "Update" pour modifier une voiture à partir de son RegistrationID
        JButton b5 = new JButton("Update");
        b5.setBounds(200, 480, 100, 40);
        b5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateCar();
            }
        });
        
        // Bouton "Average" pour calculer la moyenne des vitesses max des voitures de la BDD
        JButton b6 = new JButton("Average");
        b6.setBounds(340, 480, 100, 40);
        b6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateAndDisplayAverageSpeed();
            }
        });
        
        f.add(Lbl_RegistrationNbr);
        f.add(TF_RegistrationNbr);
        f.add(Lbl_Make);
        f.add(TF_Make);
        f.add(Lbl_Model);
        f.add(TF_Model);
        f.add(Lbl_YearOfManufacture);
        f.add(TF_YearOfManufacture);
        f.add(Lbl_TopSpeed);
        f.add(TF_TopSpeed);
        f.add(b1);
        f.add(b2);
        f.add(b3);
        f.add(b4);
        f.add(b5);
        f.add(b6);

        f.setSize(400, 300);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        // Création du tableau d'affichage pour voir la BDD
        String[] columns = {"Registration Number", "Make", "Model", "Year of Manufacture", "Top Speed"};
        tableModel = new DefaultTableModel(columns, 0);
        carTable = new JTable(tableModel);
        carTable.setBounds(20, 260, 360, 200);
        JScrollPane scrollPane = new JScrollPane(carTable);
        scrollPane.setBounds(20, 260, 360, 200);
        f.add(scrollPane);
        
        
        // Affichage initial des données de la base de données dans le tableau
        updateCarTable(carMain.getAllCars());
    }

    // Méthode pour enregistrer les données d'une nouvelle voiture
    private void saveCarDetails() {
        int registrationNbr = Integer.parseInt(TF_RegistrationNbr.getText());
        String make = TF_Make.getText();
        String model = TF_Model.getText();
        int yearOfManufacture = Integer.parseInt(TF_YearOfManufacture.getText());
        int topSpeed = Integer.parseInt(TF_TopSpeed.getText());

        Car car = new Car(registrationNbr, make, model, yearOfManufacture, topSpeed);

        if (make.isEmpty() || model.isEmpty() || yearOfManufacture == 0 || topSpeed == 0) {
            JOptionPane.showMessageDialog(f, "All boxs must be filled", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            List<Car> cars = carMain.getCarsByRegistrationNbr(registrationNbr);
            if (!cars.isEmpty()) {
                JOptionPane.showMessageDialog(f, "Car with this RegistrationID already exists", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                if (carMain.saveCar(car)) {
                    JOptionPane.showMessageDialog(f, "Car details saved successfully");
                    carMain.removeDuplicateRegistrationNbr(); 
                    updateCarTable(carMain.getAllCars()); 
                } else {
                    JOptionPane.showMessageDialog(f, "Failed to save car details.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    // Méthode pour rechercher une voiture dans la BDD grace à son RegistrationID
    private void searchCarDetails() {
        int registrationNbr = Integer.parseInt(TF_RegistrationNbr.getText());

        List<Car> cars = carMain.getCarsByRegistrationNbr(registrationNbr);
        if (!cars.isEmpty()) {
            updateCarTable(cars);
        } else {
            tableModel.setRowCount(0); 
            TF_Make.setText("");
            TF_Model.setText("");
            TF_YearOfManufacture.setText("");
            TF_TopSpeed.setText("");
            JOptionPane.showMessageDialog(f, "No cars found with the given registrationID", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Méthode pour rafraichir le tableau d'affichage à l'état initial
    private void refreshCarTable() {
        carMain.removeDuplicateRegistrationNbr(); 
        List<Car> cars = carMain.getAllCars();
        updateCarTable(cars);
    }

    // Méthode pour mettre à jour le tableau d'affichage avec les données de la nouvelle voiture sauvegardée
    private void updateCarTable(List<Car> cars) {
        tableModel.setRowCount(0);

        for (Car car : cars) {
            Object[] rowData = {
                car.getRegistrationNbr(),
                car.getMake(),
                car.getModel(),
                car.getYearOfManufacture(),
                car.getTopSpeed()
            };
            tableModel.addRow(rowData);
        }
    }

    // Méthode pour supprimer une voiture de la BDD grace à son RegistrationID
    private void deleteCar() {
        int registrationNbr = Integer.parseInt(TF_RegistrationNbr.getText());

        if (carMain.deleteCarByRegistrationNbr(registrationNbr)) {
            JOptionPane.showMessageDialog(f, "Car deleted successfully");
            updateCarTable(carMain.getAllCars()); 
            clearFields();
        } else {
            JOptionPane.showMessageDialog(f, "There is no car with this RegistrationID in the DB", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Méthode pour supprimer les champs d'écriture de l'interface
    private void clearFields() {
        TF_RegistrationNbr.setText("");
        TF_Make.setText("");
        TF_Model.setText("");
        TF_YearOfManufacture.setText("");
        TF_TopSpeed.setText("");
    }

    // Méthode pour mettre à jour les informations d'une voiture de la BDD grace à son RegistrationID
    private void updateCar() {
        int registrationNbr = Integer.parseInt(TF_RegistrationNbr.getText());

        String make = TF_Make.getText();
        String model = TF_Model.getText();
        int yearOfManufacture = Integer.parseInt(TF_YearOfManufacture.getText());
        int topSpeed = Integer.parseInt(TF_TopSpeed.getText());

        Car updatedCar = new Car(registrationNbr, make, model, yearOfManufacture, topSpeed);

        if (make.isEmpty() || model.isEmpty() || yearOfManufacture == 0 || topSpeed == 0) {
            JOptionPane.showMessageDialog(f, "All fields must be filled", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            List<Car> cars = carMain.getCarsByRegistrationNbr(registrationNbr);
            if (cars.isEmpty()) {
                JOptionPane.showMessageDialog(f, "There is no car with this RegistrationID", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                if (carMain.updateCar(updatedCar)) {
                    JOptionPane.showMessageDialog(f, "Car updated successfully");
                    updateCarTable(carMain.getAllCars()); 
                    clearFields();
                } else {
                    JOptionPane.showMessageDialog(f, "Failed to update car", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
    
    // Méthode pour calculer la moyenne des vitesses max des voitures de la BDD
    private void calculateAndDisplayAverageSpeed() {
        double averageSpeed = carMain.calculateAverageTopSpeed();

        if (averageSpeed == 0.0) {
            JOptionPane.showMessageDialog(f, "There is no car in the database", "Empty Database", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(f, "Average Top Speed : " + averageSpeed, "Average Speed", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}