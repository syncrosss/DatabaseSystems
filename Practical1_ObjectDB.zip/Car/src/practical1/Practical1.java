/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practical1;

/**
 *
 * @author nicol
 */

// Classe main de mon projet Java

public class Practical1 {
    public static void main(String[] args) {
        // Création d'un nouvelle instance de la classe CarMain
        CarMain carMain = new CarMain();
        
        // Création d'une nouvelle instance de la classe UserInterface avec la nouvelle instance carMain en paramètre
        UserInterface userInterface = new UserInterface(carMain);
    }
}
    